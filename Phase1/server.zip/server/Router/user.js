
const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')
const router = express.Router()

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json({
  type: "*/*"
}));

const connection = mysql.createConnection({
    host: 'localhost', // '127.0.0.1'
    user:  'root',
    database: 'mysql_test'
})
  
const pool = mysql.createPool({
    connectionLimit: 15,
    host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
    user: 'b4964d1079f327', //'root',
    password: '8c3f6a93', 
    database: 'heroku_178a72b8dd50777' // 'mysql_test'
})
  
function getConnection() {
    return pool
}
  
// GET all users
router.get('/users', (req, res) => {
    const queryString = "select * from users"
    getConnection().query(queryString, (err, results, fields) => {
      if (err) {
        console.log('Failed to query in data base'+ err)
        res.sendStatus(500)
        res.end()
      } else {
        //res.json(results)
        const mapedUsers = results.map((eachResult) => {
          return { "id":eachResult.id, "firstName": eachResult.first_name, lastName: eachResult.last_name }
        })
        res.json(mapedUsers)
      }
    })
})
  
  // GET an one user by user_id
router.get('/user/:id', (req, res) => {
    const userId = req.params.id
    console.log('fetching user data'+ userId)
    const queryString = "select * from users where id = ?"
    getConnection().query(queryString, [userId], (error, results, fields) => {
      if (error) {
        console.log("having some fetching error: "+error)
        res.sendStatus(500)
        res.end()
      } else {
        const mappedUser = results.map((eachResult) => {
          return { "id":eachResult.id, "firstName": eachResult.first_name, lastName: eachResult.last_name, address: eachResult.address }
        })
        res.json(mappedUser)
      }
    })
})
  
  
  // create a new user record
router.post('/user_create', (req, res) => {
    const firstName = req.body.first_name
    const lastName = req.body.last_name
    const address = req.body.address
    const queryString = "insert into users (first_name, last_name, address) values (?,?,?)"
    console.log(firstName, lastName, address)
  
    getConnection().query(queryString, [firstName, lastName, address], (err, results, fields) => {
      if (err) {
        console.log("having some error to create a new user" + err)
        res.sendStatus(500)
        res.end()
        return
      }
      console.log('new user insertion is success')
      res.json({success: true})
      res.end()
    })
})
  
  // update a user record
router.post('/update_user', (req, res) => {
    const firstName = req.body.first_name
    const lastName = req.body.last_name
    const id = req.body.id
    const address = req.body.address
    const queryString = "update users set first_name = ?, last_name= ?, address= ? where id = ?"
    console.log(firstName, lastName, address, id)
  
    getConnection().query(queryString, [firstName, lastName, address, id], (err, results, fields) => {
      if (err) {
        console.log("having some error to update user" + err)
        res.sendStatus(500)
        res.end()
        return
      }
      console.log('user recorded updated')
      res.json({success: true})
      res.end()
    })
})
  
  // delete a record
router.post('/delete_user/:id', (req, res) => {
    const id = req.params.id
    const queryString = "delete from users where id = ?"
    getConnection().query(queryString, [id], (err, results, fields) => {
      if (err) {
        console.log("having some error to create a new user" + err)
        res.sendStatus(500)
        res.end()
        return
      }
      console.log('user has been deleted')
      res.json({success: true})
      res.end()
    })
})

module.exports = router


