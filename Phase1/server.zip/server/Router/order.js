const express = require('express')
var pool = require('../database.js')
const bodyParser = require('body-parser')
const router = express.Router()

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json({
  type: "*/*"
}));


// place an order: POST call
router.post('/placeOrder', async (req, res) => {
    const email = req.body.email;
    const items = req.body.items;
    var fields = []
    for (let item of items) { 
        fields.push(`('${email}',${item.id},'${item.cat}','${item.subCat}','${item.qty}')`)
    }
    let queryString = `INSERT INTO super_order (email, product_id, category, subcategory, quantity)  VALUES ${fields.join(',')}`;
    try {
        await pool.query(queryString);
    }catch(e) {
        console.log('Failed to query in data base'+ e)
        res.sendStatus(500)
        res.end()
        return;
      }
    res.json({ text: "Order place successfully"});
})

module.exports = router;