const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')
const util = require('util')
const router = express.Router()

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json({
  type: "*/*"
}));

const pool = mysql.createPool({
    connectionLimit: 15,
    host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
    user: 'b4964d1079f327', //'root',
    password: '8c3f6a93', 
    database: 'heroku_178a72b8dd50777' // 'mysql_test'
})
  
function getConnection() {
    return pool
}

// GET all products
router.get('/products', (req, res) => {
    const queryString = "select * from super_product"
    getConnection().query(queryString, (err, results, fields) => {
      if (err) {
        console.log('Failed to query in data base'+ err)
        res.sendStatus(500)
        res.end()
      } else {
        res.json(results)
      }
    })
})

// Ping database to check for common exception errors.
pool.getConnection((err, connection) => {
  if (err) {
      if (err.code === 'PROTOCOL_CONNECTION_LOST') {
          console.error('Database connection was closed.')
      }
      if (err.code === 'ER_CON_COUNT_ERROR') {
          console.error('Database has too many connections.')
      }
      if (err.code === 'ECONNREFUSED') {
          console.error('Database connection was refused.')
      }
  }

  if (connection) connection.release()

  return
})

pool.query = util.promisify(pool.query)


// POST call: get products based on category and subCategory search
router.post('/productList', async (req, res) => {
    
    
    const email = req.body.id;
    const items = req.body.items;
    var results = []
    let queryString = `select distinct product_id from super_order where email = '${email}'`;
    let orderResult = await pool.query(queryString);
    var orderData = orderResult.map(or => or.product_id);
    for (let item of items) { 
        queryString = "select * from super_product where category = ? and subcategory like ?"

      try {
        var result = await pool.query(queryString,[item.cat,`%${item.subCat}%`]);

        if(email) {
          
          let topItem = [];
          let restItem = [];
          
          for (let product of result) {
            let index = orderData.indexOf(product.id);
            if(index > -1) {
              let tempProduct = product
              tempProduct.preselected = true
              topItem.push(tempProduct);
              
              delete orderData[index];
            } else{ 
              restItem.push(product)
            }
          };
         
          result = [...topItem,...restItem];
        }
      } catch(e) {
        console.log('Failed to query in data base'+ e)
        res.sendStatus(500)
        res.end()
        return;
      }

      // retrieve promotion/offer text 
      let promotionText = `select message from super_message where category = '${item.cat}'`;
      let text = await pool.query(promotionText);
      results.push({ name: item.cat, products: result, promotions: text.length > 0 ? text[0]: {} })
    }
    
    let missingIds = [];
      for (let order of orderData)  {
        order && missingIds.push(order) 
      }
      let missingCatProds= [];
      if(missingIds.length > 0){
        missingIds = missingIds.join(",");
        queryString = `select* from super_product where id in (${missingIds})`;
        missingCatProds = await pool.query(queryString);
      }
      res.json({ categories: results, missingItems: missingCatProds})
})

module.exports = router;