const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')
const util = require('util')
const router = express.Router()

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json({
  type: "*/*"
}));

const pool = mysql.createPool({
    connectionLimit: 15,
    host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
    user: 'b4964d1079f327', //'root',
    password: '8c3f6a93', 
    database: 'heroku_178a72b8dd50777' // 'mysql_test'
})
  
function getConnection() {
    return pool
}

// GET all products
router.get('/products', (req, res) => {
    const queryString = "select * from super_product"
    getConnection().query(queryString, (err, results, fields) => {
      if (err) {
        console.log('Failed to query in data base'+ err)
        res.sendStatus(500)
        res.end()
      } else {
        res.json(results)
      }
    })
})

// Ping database to check for common exception errors.
pool.getConnection((err, connection) => {
  if (err) {
      if (err.code === 'PROTOCOL_CONNECTION_LOST') {
          console.error('Database connection was closed.')
      }
      if (err.code === 'ER_CON_COUNT_ERROR') {
          console.error('Database has too many connections.')
      }
      if (err.code === 'ECONNREFUSED') {
          console.error('Database connection was refused.')
      }
  }

  if (connection) connection.release()

  return
})

pool.query = util.promisify(pool.query)


// POST call: get products based on category and subCategory search
router.post('/productList', async (req, res) => {
    const queryString = "select * from super_product"
    const id = req.body.id;
    const items = req.body.item;
    var results = []
    for (let item of items) { 
      let queryString = "select * from super_product where category = ? and subcategory like ?"
      try {
        var result = await pool.query(queryString,[item.cat,`%${item.subCat}%`]);
        if(id){
          let queryString = `select distinct products from super_order where id = '${id}' and category = '${item.cat}' and subcategory like '%${item.subCat}%'`;
          let orderResult = await pool.query(queryString);
          var orderData = orderResult.map(or => or.products);
          let topItem = [];
          let restItem = [];
          for (let product of result)  {
            if(orderData.indexOf(product.id) > -1){
              topItem.push(product)
            } else{ 
              restItem.push(product)
            }
          };
          result = [...topItem,...restItem];
        }
      }catch(e) {
        console.log('Failed to query in data base'+ e)
        res.sendStatus(500)
        res.end()
        return;
      }
      results.push(result)
    }
    console.log(results);
    res.send(results);
})

module.exports = router;