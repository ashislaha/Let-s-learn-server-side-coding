const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')
const router = express.Router()

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json({
  type: "*/*"
}));

const pool = mysql.createPool({
    connectionLimit: 15,
    host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
    user: 'b4964d1079f327', //'root',
    password: '8c3f6a93', 
    database: 'heroku_178a72b8dd50777' // 'mysql_test'
})
  
function getConnection() {
    return pool
}

// GET all products
router.get('/products', (req, res) => {
    const queryString = "select * from super_product"
    getConnection().query(queryString, (err, results, fields) => {
      if (err) {
        console.log('Failed to query in data base'+ err)
        res.sendStatus(500)
        res.end()
      } else {
        res.json(results)
      }
    })
})

// POST call: retrieve only selected product based on request
// router.post('/getProductList', (req, res) => {

// })

module.exports = router;