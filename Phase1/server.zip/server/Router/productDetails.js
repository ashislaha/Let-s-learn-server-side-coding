const express = require('express')
const mysql = require('mysql')
const bodyParser = require('body-parser')
const util = require('util')
const router = express.Router()

router.use(bodyParser.urlencoded({ extended: false }))
router.use(bodyParser.json({
  type: "*/*"
}));

const connection = mysql.createConnection({
    host: 'localhost', // '127.0.0.1'
    user:  'root',
    database: 'mysql_test'
})
  
const pool = mysql.createPool({
    connectionLimit: 15,
    host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
    user: 'b4964d1079f327', //'root',
    password: '8c3f6a93', 
    database: 'heroku_178a72b8dd50777' // 'mysql_test'
})
  
function getConnection() {
    return pool
}

// Ping database to check for common exception errors.
pool.getConnection((err, connection) => {
    if (err) {
        if (err.code === 'PROTOCOL_CONNECTION_LOST') {
            console.error('Database connection was closed.')
        }
        if (err.code === 'ER_CON_COUNT_ERROR') {
            console.error('Database has too many connections.')
        }
        if (err.code === 'ECONNREFUSED') {
            console.error('Database connection was refused.')
        }
    }
  
    if (connection) connection.release()
  
    return
  })
  
  pool.query = util.promisify(pool.query)
  
// GET the product details
router.get('/productDetails/:id', async (req, res) => {

    const productId = req.params.id

    // retrive details
    const queryString = `select * from super_product where id = '${productId}'`
    let product = await pool.query(queryString);
    
    // retrive bought_together
    var boughtTogetherProducts = []
    const fetchBoughtTogether = `select * from super_bought_together where id = '${productId}'`
    let boughtTogetherResult = await pool.query(fetchBoughtTogether);
    if (boughtTogetherResult.length > 0) {
        let item = boughtTogetherResult[0]

        let boughtItems = []
        let neighbor1 = item.neighbor1
        if (neighbor1) { boughtItems.push(neighbor1) }
        let neighbor2 = item.neighbor2
        if (neighbor2) { boughtItems.push(neighbor2) }
        let neighbor3 = item.neighbor3
        if (neighbor3) { boughtItems.push(neighbor3) }
        let neighbor4 = item.neighbor4
        if (neighbor4) { boughtItems.push(neighbor4) }
        let neighbor5 = item.neighbor5
        if (neighbor5) { boughtItems.push(neighbor5) }

        if (boughtItems.length > 0) {
            for (var i = 0; i < boughtItems.length; i++) {
                const fetchProduct = `select * from super_product where id = '${boughtItems[i]}'`
                let productArr = await pool.query(fetchProduct);

                if (productArr.length > 0) {
                    boughtTogetherProducts.push(productArr[0])
                }
            }
        }
    }

    // retrieve similar products - (similar products are those having same category except current product_id)
    var similarProducts = []
    if (product.length > 0) {
        let category = product[0].category
        const fetchSameCategoryProducts = `select * from super_product where category = '${category}' and id != '${productId}'`
        similarProducts = await pool.query(fetchSameCategoryProducts);
    }
    
    res.json({ 
        productDetails: product.length > 0 ? product[0] : { },
        bought_together: boughtTogetherProducts,
        similar_products: similarProducts
    })
})

module.exports = router;