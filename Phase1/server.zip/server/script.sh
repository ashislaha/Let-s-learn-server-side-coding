git add .
git commit -m " tfvgbhjn"
git push heroku
heroku logs
