const requestAPI = require('request-promise')
const apiKey = 'r8sva9uw6adq4jujmmq6napd'
module.exports = {

  searchProduct: function(prodCategory, prod, res) {
    console.log(prodCategory);
  requestAPI('http://api.walmartlabs.com/v1/search?query='+prod+'&format=json&apiKey='+apiKey)
  .then(function(data){
    var resp = JSON.parse(data);
    let item1 = resp.items[0].name+'\nPrice: '+resp.items[0].salePrice+'\nStatus: '+resp.items[0].stock+'\n';
    let item2 = resp.items[1].name+'\nPrice: '+resp.items[1].salePrice+'\nStatus: '+resp.items[1].stock+'\n';
    let item3 = resp.items[2].name+'\nPrice: '+resp.items[2].salePrice+'\nStatus: '+resp.items[2].stock+'\n';

    // message dictionary
    let messages = [{
      "type": 1,
      "title": item1,
      "subtitle": prodCategory,
      "productName": prod,
      "imageUrl": resp.items[0].largeImage
    }, {
      "type": 1,
      "title": item2,
      "subtitle": prodCategory,
      "productName": prod,
      "imageUrl": resp.items[1].largeImage
    }, {
      "type": 1,
      "title": item3,
      "subtitle": prodCategory,
      "productName": prod,
      "imageUrl": resp.items[2].largeImage
    }]
    res.send(JSON.stringify({'messages': messages }));

    });
  },


  productReview: function(prod, res) {
  requestAPI('http://api.walmartlabs.com/v1/search?query='+prod+'&format=json&apiKey=5hnyas9jvdsdw78ca9uxyb6s')
 .then(function(data){
    let resp = JSON.parse(data);
    let itemId = resp.items[0].itemId;
    return itemId;})
  .then(function(data){
        requestAPI('http://api.walmartlabs.com/v1/reviews/'+data+'?format=json&apiKey=5hnyas9jvdsdw78ca9uxyb6s')
 .then(function(data){
     let resp = JSON.parse(data);
     console.log(resp);
     res.send(JSON.stringify({ 'speech': resp.reviews[0].reviewText, 'displayText': resp.reviews[0].reviewText}));

   });
});
},


nearbyStores: function(city, res) {
    requestAPI('http://api.walmartlabs.com/v1/stores?format=json&city='+city+'&apiKey=5hnyas9jvdsdw78ca9uxyb6s')
    .then(function(data){
    let resp = JSON.parse(data);
    let googleResp = '\nStore 1: '+resp[0].name+' \n  Address: '+resp[0].streetAddress+'\n'+'  Contact: '+resp[0].phoneNumber;
    googleResp += '\n\nStore 2: '+resp[1].name+' \n  Address: '+resp[1].streetAddress+'\n'+'  Contact: '+resp[1].phoneNumber;
    googleResp += '\n\nStore 3: '+resp[2].name+' \n  Address: '+resp[2].streetAddress+'\n'+'  Contact: '+resp[2].phoneNumber;
    googleResp += '\n\nStore 4: '+resp[3].name+' \n  Address: '+resp[3].streetAddress+'\n'+'  Contact: '+resp[3].phoneNumber;
    googleResp += '\n\nStore 5: '+resp[4].name+' \n  Address: '+resp[4].streetAddress+'\n'+'  Contact: '+resp[4].phoneNumber;
    res.send(JSON.stringify({ 'speech': googleResp, 'displayText': googleResp}));
  })
},

welcome: function(res){
  var resp = 'Hello, Welcome to my Dialogflow agent!'
  res.send(JSON.stringify({ 'speech': resp, 'displayText': resp}));

},

unknown: function(res){
  var resp = 'I\'m having trouble, can you try that again?';
  res.send(JSON.stringify({ 'speech': resp, 'displayText': resp}));
},

addToCart: function(itemInd, product, res){
  requestAPI('http://api.walmartlabs.com/v1/search?query='+product+'&format=json&apiKey=5hnyas9jvdsdw78ca9uxyb6s')
  .then(function(data){
  let resp = JSON.parse(data);
  let addCartURL = resp.items[itemInd].addToCartUrl;
  //
  return addCartURL;
}).then(function(data){
  //srequestAPI(data);
  var resp = 'Item successfully added to your cart.';
  res.send(JSON.stringify({ 'speech': resp, 'displayText': resp}));

  });
},

searchProductInStore: function(pool, number, product, res){
  number = 1
  const queryString = "select storeproducts.spec, storeproducts.price, storeproducts.status from storeproducts inner join storedetails on storeproducts.id=storedetails.productid where storedetails.storeid = ? and storeproducts.prodName=?"
  pool.query(queryString, [number, product], (err, results, fields) => {
    if (err) {
      console.log('Failed to query'+ err)
      res.sendStatus(500)
      res.end()
    } else {
      let resp = JSON.stringify(results[1]);
      var len = results.length;
      var response='',i;
      for(i=1; i<=len ; i++){
        response += '\n\nItem '+i+' : '+results[i-1].spec+'\nPrice: '+results[i-1].price+'\nStatus: '+results[i-1].status;
    }
      //console.log()
      //let resp = JSON.parse(results);
      res.send(JSON.stringify({ 'speech': response, 'displayText': response}))
    }
  })
},

navigation: function(product, res){
  var resp = product
  res.send(JSON.stringify({ 'speech': resp, 'displayText': resp}));

},

userWishListHandler: function(param, res){
  // var resp = " Your wishList is recorded. We will help you to navigate through your wishList.";
  console.log(param);
  var  set1 = new Set();
  for (elem in param)  {
    set1.add(param[elem]);
  }
  let a=Array.from(set1);
  var messages = [];
  for (elem in a) {
    var obj = {
      "type": 1,
      "name": param[elem]
    }
    messages.push(obj);
  }
  res.send(JSON.stringify({'messages': messages }));
},

showUserOffer: function(pool, res){

  var response="",i;
  const queryString = "select userId, itemPurchsed from userhistory where userId=123 group by itemPurchsed order by count(*) desc limit 2"
  pool.query(queryString, (err, results, fields) => {
    if (err) {
      console.log('Failed to query'+ err)
      res.sendStatus(500)
      res.end()
    } else {
       // for(i=1; i<=results.length ;i++){
            const queryString2 = "select description from "+ results[0].itemPurchsed + "table inner join offer on " + results[0].itemPurchsed +"table.offerId=offer.offerId"
            pool.query(queryString2, (err, results2, fields) => {
              if (err) {
                console.log('Failed to query'+ err)
                res.sendStatus(500)
                res.end()
              }
              else {
                var len2 = results2.length, j;
                for(j=1; j<=len2 ; j++){
                   response += results2[j-1].description + '\n\n';
                }
                //res.send(JSON.stringify({ 'speech': response, 'displayText': response}))
              }
          })

          const queryString3 = "select description from "+ results[1].itemPurchsed + "table inner join offer on " + results[1].itemPurchsed +"table.offerId=offer.offerId"
          pool.query(queryString3, (err, results2, fields) => {
            if (err) {
              console.log('Failed to query'+ err)
              res.sendStatus(500)
              res.end()
            }
            else {
              var len2 = results2.length, j;
              for(j=1; j<=len2 ; j++){
                 response += results2[j-1].description + '\n\n';
              }
               res.send(JSON.stringify({ 'speech': response, 'displayText': response}))
            }
        })


        // }
     //res.send(JSON.stringify({ 'speech': response, 'displayText': response}))
    }

  })
},

default: function(res){
  speech: 'Hey, I am still learning! '
  displayText: 'Hey, I am still learning!'

  res.send(JSON.stringify({ 'speech': speech, 'displayText': displayText}));

}

// add for offers

// add for


};
