// load our application server using express
const requestAPI = require('request-promise');
const express = require('express')
const app = express()
const morgan = require('morgan')
const bodyParser = require('body-parser')
const mysql = require('mysql')

const dialogflowActions = require('./dialogflowActions')
const userRouter = require('./Router/user.js')
const mobileRouter = require('./Router/mobiles.js')
const productRouter = require('./Router/product.js')

app.use(userRouter)
app.use(mobileRouter)
app.use(productRouter)

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json({
  type: "*/*"
}));
app.use(morgan('short'))
app.use(express.static('./public')) // folder name

const pool = mysql.createPool({
  connectionLimit: 15,
  host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
  user: 'b4964d1079f327', //'root',
  password: '8c3f6a93',
  database: 'heroku_178a72b8dd50777' // 'mysql_test'
})

function getConnection() {
  return pool
}

app.get('/', (req, res) => {
  console.log("responding to root route")
  res.send("Hello world, I am responding from route. \nMore details check </b>https://github.com/ashislaha/Let-s-learn-server-side-coding</b> ... Ashis")
})

// This is for webhook in dialogflow
app.post('/', (req, res) => {

  let action = req.body.result.action;
  const parameters = req.body.result.parameters;
  const inputContexts = req.body.result.contexts;
  const requestSource = (req.body.result) ? req.body.result.source : undefined;

  console.log(action)

  if(action === 'input.welcome') {
    dialogflowActions.welcome(res)
  } else if(action === 'input.unknown') {
    dialogflowActions.unknown(res)
  } else if (action === 'input.searchproduct') {
    //console.log(re);
    //console.log("****", req.body.result);
     var prod = parameters.product
     var prodCategory = parameters.productToCategory
     dialogflowActions.searchProduct(prodCategory, prod, res);
  } else if (action === 'input.productreview') {
    var prod = parameters.product
    dialogflowActions.productReview(prod, res);
  } else if (action === 'input.nearbystores') {
    var city = parameters["geo-city"]
    dialogflowActions.nearbyStores(city, res);
  } else if(action === 'search-product.search-product-custom') {
    let itemInd = parameters["number-integer"]
    let product = inputContexts[0].parameters["product"];
    dialogflowActions.addToCart(itemInd, product, res);
  } else if(action === 'nearby-stores.nearby-stores-custom') {
    console.log(parameters);
    dialogflowActions.searchProductInStore(getConnection(), parameters.number, parameters.product, res);
  } else if(action === 'input.navigation') {
    console.log(parameters);
    dialogflowActions.navigation(parameters.product, res);
  }
  else if(action === 'input.userOffer') {
    dialogflowActions.showUserOffer(getConnection(), res);
  }
  else if(action == 'input.wishListYes-custom'){
    dialogflowActions.userWishListHandler(parameters.ProductToCategory, res);
  }
   else {
    dialogflowActions.default(res);
  }
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    console.log('server is up and listening on port: '+ PORT)
})
