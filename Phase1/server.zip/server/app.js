// load our application server using express

const express = require('express')
const app = express()
const morgan = require('morgan')

app.use(morgan('short'))
app.use(express.static('./public')) // folder name

const router = require('./Router/user.js')
app.use(router)

app.get('/', (req, res) => {
  console.log("responding to root route")
  res.send("Hello world, I am responding from route")
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    console.log('server is up and listening on port: '+ PORT)
})
