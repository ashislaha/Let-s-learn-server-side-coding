// load our application server using express

const express = require('express')
const app = express()
const morgan = require('morgan')
const bodyParser = require('body-parser')
const mysql = require('mysql')

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json({
  type: "*/*"
}));
app.use(morgan('short'))
app.use(express.static('./public')) // folder name

const userRouter = require('./Router/user.js')
app.use(userRouter)

const mobileRouter = require('./Router/mobiles.js')
app.use(mobileRouter)

const pool = mysql.createPool({
  connectionLimit: 15,
  host: 'us-cdbr-iron-east-04.cleardb.net', //'localhost',
  user: 'b4964d1079f327', //'root',
  password: '8c3f6a93', 
  database: 'heroku_178a72b8dd50777' // 'mysql_test'
})

function getConnection() {
  return pool
}

app.get('/', (req, res) => {
  console.log("responding to root route")
  res.send("Hello world, I am responding from route")
})

// This is for webhook in dialogflow
app.post('/', (req, res) => {
  const queryString = "select * from mobiles"
  getConnection().query(queryString, (err, results, fields) => {
    if (err) {
      console.log('Failed to query in mobiles data base'+ err)
      res.sendStatus(500)
      res.end()
    } else {
      res.send({fulfillmentText: "I am from web service:" + JSON.stringify(results), source: "dialogflow webhook mobiles" })
      res.json(jsonObject)
    }
  })
})

const PORT = process.env.PORT || 3000
app.listen(PORT, () => {
    console.log('server is up and listening on port: '+ PORT)
})
