
// create a connection
const http = require('http');

// create a host name
const hostname = '127.0.0.1'

// create a port 
const port = 3000

// If you want to bring a file / open a file while server started
const fs = require('fs');
fs.readFile('index.html' , (err, html)=> {

	if (err) {
		throw err;
	}

	// create a server

	const server = http.createServer((req,res) => {
	// setup res
		res.statusCode = 200;
		res.setHeader('Content-type', 'text/html');
		res.write(html); // output of "index.html"
		res.end();
		//res.end('Hello World');
	});

	server.listen(port,hostname, ()=> {
		console.log('server started on port' + port);
	});

});
